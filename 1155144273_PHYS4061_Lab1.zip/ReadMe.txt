This program consist of following library:
#include <iostream>
#include <vector>
#include <cstdlib>
#include <time.h>
#include <fstream>
#include <cmath>
#include <numeric>

_____________________________________

Note all xyz file are stored in folder naming 'xyz'

Each file name is refering its lattice structure. For example , Cubic refers to Simple cubic structure. Diamond refer diamond.